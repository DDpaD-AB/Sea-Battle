﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        Label label1 = new Label();
        public Form1()
        {
            InitializeComponent();
            Аы();
            
            Controls.Add(label1);
            label1.Location = new Point(20, 440);
            label1.Size = new Size(70, 20);
        }
        public void Аы() 
        {
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Button button = new Button();
                    button.Name = $"bt{i}{j}";
                    button.Text = $"Аы {i+1} {j+1}";
                    button.Size = new Size(40,40);
                    button.Location = new Point(40*j,40*i);
                    Controls.Add(button);
                    button.Click += new EventHandler(Aboba);
                }
            }
        }
        public void Aboba(object sender, EventArgs e)
        {
            char[] chars = Convert.ToString(((Button)sender).Name).ToCharArray();
            int prekol1 = int.Parse(Convert.ToString(chars[2]));
            int prekol2 = int.Parse(Convert.ToString(chars[3]));
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (prekol1+i-1!=-1 && prekol1+i-1!=10 && prekol2+j-1 != -1 && prekol2+j-1 != 10)
                    {
                        this.Controls[$"bt{prekol1 + i - 1}{prekol2 + j - 1}"].BackColor = Color.Red;
                    }
                }
            }

        }

    }
}
